/*
 * Modified from g_density, 30.7.2004/PSN
 *
 * $Id: g_density.c,v 1.21 2002/02/28 11:00:25 spoel Exp $
 * 
 *                This source code is part of
 * 
 *                 G   R   O   M   A   C   S
 * 
 *          GROningen MAchine for Chemical Simulations
 * 
 *                        VERSION 3.1
 * Copyright (c) 1991-2001, University of Groningen, The Netherlands
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * If you want to redistribute modifications, please consider that
 * scientific software is very special. Version control is crucial -
 * bugs must be traceable. We will be happy to consider code for
 * inclusion in the official distribution, but derived work must not
 * be called official GROMACS. Details are found in the README & COPYING
 * files - if they are missing, get the official version at www.gromacs.org.
 * 
 * To help us fund GROMACS development, we humbly ask that you cite
 * the papers on the package - you can find them in the top README file.
 * 
 * For more info, check our website at http://www.gromacs.org
 * 
 * And Hey:
 * Gromacs Runs One Microsecond At Cannonball Speeds
 */
static char *SRCID_g_density_c = "$Id: g_density.c,v 1.21 2002/02/28 11:00:25 spoel Exp $";
#include <math.h>
#include <ctype.h>
#include "sysstuff.h"
#include "string.h"
#include "string2.h"
#include "typedefs.h"
#include "smalloc.h"
#include "macros.h"
#include "gstat.h"
#include "vec.h"
#include "xvgr.h"
#include "pbc.h"
#include "copyrite.h"
#include "futil.h"
#include "statutil.h"
#include "rdgroup.h"
#include "tpxio.h"

typedef struct {
  char *atomname;
  int nr_el;
} t_electron;

/****************************************************************************/
/* This program calculates the partial density across the box.              */
/* Peter Tieleman, Mei 1995                                                 */
/****************************************************************************/



/* used for sorting the list */
int compare(void *a, void *b)
{
  t_electron *tmp1,*tmp2;
  tmp1 = (t_electron *)a; tmp2 = (t_electron *)b;

  return strcmp(tmp1->atomname,tmp2->atomname);
}



int get_electrons(t_electron **eltab, char *fn)
{
  char buffer[256];  /* to read in a line   */
  char tempname[80]; /* buffer to hold name */
  int tempnr; 

  FILE *in;
  int nr;            /* number of atomstypes to read */
  int i;

  if ( !(in = fopen(fn,"r")))
    gmx_fatal(FARGS,"Couldn't open %s. Exiting.\n",fn);

  fgets(buffer, 255, in);
  if (sscanf(buffer, "%d", &nr) != 1)
    gmx_fatal(FARGS,"Invalid number of atomtypes in datafile\n");

  snew(*eltab,nr);

  for (i=0;i<nr;i++) {
    if (fgets(buffer, 255, in) == NULL)
      gmx_fatal(FARGS,"reading datafile. Check your datafile.\n");
    if (sscanf(buffer, "%s = %d", tempname, &tempnr) != 2)
      gmx_fatal(FARGS,"Invalid line in datafile at line %d\n",i+1);
    (*eltab)[i].nr_el = tempnr;
    (*eltab)[i].atomname = strdup(tempname);
  }
  
  /* sort the list */
  fprintf(stderr,"Sorting list..\n");
  qsort ((void*)*eltab, nr, sizeof(t_electron), 
	 (int(*)(const void*, const void*))compare);

  return nr;
}



void calc_electron_density(char *fn, atom_id **index, int gnx[], 
			   real ***slDensity, real *slicesize, t_topology *top, int ePBC, 
			   int axis, int nr_grps, real *slWidth, 
			   t_electron eltab[], int nr, bool bRC, bool bCharge)
{
  rvec *x0;              /* coordinates without pbc */
  matrix box;            /* box (3x3) */
  int natoms,            /* nr. atoms in trj */
    status,  
    i,n,k,j,m,p[2],               /* loop indices */
    ax1=0, ax2=0,
    nr_frames = 0, nr_frames2 = 0,     /* number of frames */
    slice[3],nx,ny,nz,skip,             /* current slice */
    com[3],count,count2,count3;
  t_electron *found;     /* found by bsearch */
  t_electron sought;     /* thingie thought by bsearch */
  real t, z;
/* PSN 30.7.2004 */ 
  FILE *putget,*putget2,*AREAout;
  double sum1, sum2,coord[3],*localdensity,*localdensity2,*areacount,*areacount1,*areacount2,*areacount3,*area,*area2,*area3,max=0,min=0;
  float zzz_shift, zzz_moveto, zzz_ave, ttt,unitr[2],invlength;   
/* PSN 30.7.2004 */ 
 
/*  switch(axis) {
  case 0:
    ax1 = 1; ax2 = 2;
    break;
  case 1:
    ax1 = 0; ax2 = 2;
    break;
  case 2:
    ax1 = 0; ax2 = 1;
    break;
  default:
    gmx_fatal(FARGS,"Invalid axes. Terminating\n");
    }*/

  if ((natoms = read_first_x(&status,fn,&t,&x0,box)) == 0)
    gmx_fatal(FARGS,"Could not read coordinates from statusfile\n");

  /*  if (! *nslices)
    *nslices = (int)(box[axis][axis] * 10); default value 
  fprintf(stderr,"\nDividing the box in %d slices\n",*nslices);

  snew(*slDensity, nr_grps);
  for (i = 0; i < nr_grps; i++)
    snew((*slDensity)[i], *nslices);*/
  
/* PSN 30.7.2004 */
/*    zzz_moveto = 5.0;
 *slWidth = 10.0/(*nslices);*/
//  zzz_moveto = (box[axis][axis]+1.0)/2.0; 
//  *slWidth = (box[axis][axis] + 1.0)/(*nslices);

/*  if(bRC) */
  putget = fopen("proteinformDENS.dat", "w");
  putget2 = fopen("proteinformDENS2.dat", "w");
  AREAout = fopen("area.dat","w");
    /*  else
    putget = fopen("centers.dat", "a");
  if(putget==NULL) {
    fprintf(stderr, "Error in opening centers.dat!\n");  
    exit(1);*/
/*}*/
/* PSN 30.7.2004 */
    
  nx= box[0][0] / *slicesize;
  ny= box[1][1] / *slicesize;
  nz= box[2][2] / *slicesize;
 
  /*  com[0]=(int) 5.75 / *slicesize;
  com[1]=(int) 5.76 / *slicesize;
  com[2]=(int) 9.01 / *slicesize;*/

  sum1=0.0;
  for(k=0;k<3;k++)
    coord[k]=0;
  for (i = 0; i < gnx[1]; i++) {   /* loop over all atoms in index file */
    for(k=0;k<3;k++)
      coord[k] += x0[index[1][i]][k]; 
    sum1++;
  }
  for(k=0;k<3;k++)
    com[k]=(int) ((coord[k]/sum1) / *slicesize);
  fprintf(stderr,"%i %i %i %f %f %f \n",com[0],com[1],com[2],coord[0]/sum1,coord[1]/sum1,*slicesize);
  
  localdensity = (double*)malloc(nx*ny*nz*sizeof(double));
  localdensity2 = (double*)malloc(nx*ny*nz*sizeof(double));
  areacount = (double*)malloc(nx*ny*nz*sizeof(double));
  areacount1 = (double*)malloc(nx*ny*nz*sizeof(double));
  areacount2 = (double*)malloc(nx*ny*nz*sizeof(double));
  areacount3 = (double*)malloc(nx*ny*nz*sizeof(double));
  area = (double*)malloc(nz*sizeof(double));
  area2 = (double*)malloc(nz*sizeof(double));
  area3 = (double*)malloc(nz*sizeof(double));

  for(i=0;i<nx;i++)
    for(j=0;j<ny;j++)
      for(k=0;k<nz;k++){
	areacount[i*ny*nz+j*nz+k]=0;
	localdensity[i*ny*nz+j*nz+k]=0;
	localdensity2[i*ny*nz+j*nz+k]=0;
      }

  for(i=0;i<nx;i++)
    for(j=0;j<ny;j++)
      for(k=0;k<nz;k++){
	area[k]=0;
	area2[k]=0;
	area3[k]=0;
      }
  /*********** Start processing trajectory ***********/
  do {
    rm_pbc(&(top->idef),ePBC,top->atoms.nr,box,x0,x0);
    
    /* PSN 6.8.2007, rewritten to work with multiple groups */
    
    /* PSN 30.7.2004 */
    
    sum1 = 0.0;
    for (n = 0; n < nr_grps; n++) {      
      for (i = 0; i < gnx[n]; i++) {   /* loop over all atoms in index file */
	
	for(k=0;k<3;k++){
	  coord[k] = x0[index[n][i]][k]; 
	  if (z < 0) 
	    z += box[k][k];
	  if (z > box[k][k])
	    z -= box[k][k];
	}
	/* z = z - zzz_shift;  PSN 30.7.2004 */
	/* determine which slice atom is in */
	
	slice[0] = (coord[0] / (box[0][0]/nx)); 
	slice[1] = (coord[1] / (box[1][1]/ny)); 
	slice[2] = (coord[2] / (box[2][2]/nz)); 
	
	skip=0;
	for(k=0;k<3;k++)
	  if(slice[k] < 0) skip=1; /*slice[k] = 0;*/
	
	if(slice[0] >= nx) skip=1; /*slice[0] = nx-1;*/
	if(slice[1] >= ny) skip=1; /*slice[1] = ny-1;*/
	if(slice[2] >= nz) skip=1; /*slice[2] = nz-1;*/
   
	
	
	/*	if(slice[0]>nx || slice[1]>ny||slice[2]>nz)*/
	/*	fprintf(stderr,"%i %i %i \n",slice[0],slice[1],slice[2]);*/
	if(skip==0 && n==0){
	  localdensity[slice[0]*ny*nz+slice[1]*nz+slice[2]]++;
	  areacount[slice[0]*ny*nz+slice[1]*nz+slice[2]]=1;
	}
	if(skip==0 && n==1){
	  localdensity2[slice[0]*ny*nz+slice[1]*nz+slice[2]]++;
	}
	
      }
    }
    nr_frames++;
    
    if(nr_frames==100){
      for(i=0;i<nx;i++)
	for(j=0;j<ny;j++)
	  for(k=0;k<nz;k++){
	    areacount1[i*ny*nz+j*nz+k]=0;
	    areacount2[i*ny*nz+j*nz+k]=0;
	    areacount3[i*ny*nz+j*nz+k]=0;
	  }

      /*      for(i=0;i<nx;i++)
	for(j=0;j<ny;j++)
	  for(k=0;k<nz;k++){
	    area[k]=0;
	    area2[k]=0;
	    area3[k]=0;
	    }*/
      
      m=0;
      count=0;
      count2=0;
      count3=0;
      p[0]=com[0];
      p[1]=com[1];
      
      
      for(k=0;k<nz;k++){
	for(i=0;i<nx;i++){
	  unitr[0]=i-com[0];
	  unitr[1]=-com[1];
	  invlength=1/sqrt(unitr[0]*unitr[0]+unitr[1]*unitr[1]);
	  unitr[0]=unitr[0]*invlength;
	  unitr[1]=unitr[1]*invlength;
	  while(p[0]>0 && p[1]>0 && p[0]<nx && p[1]<ny){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    if(areacount[p[0]*ny*nz+p[1]*nz+k]>0 && count==0)
	      count=m;
	    /*	areacount1[p[0]*ny*nz+p[1]*nz+k]=count;*/
	    if(localdensity[p[0]*ny*nz+p[1]*nz+k]>localdensity2[p[0]*ny*nz+p[1]*nz+k] && count2==0)
	      count2=m;
	    /*	areacount2[p[0]*ny*nz+p[1]*nz+k]=count2;*/
	    if(areacount[p[0]*ny*nz+p[1]*nz+k]>0 && localdensity2[p[0]*ny*nz+p[1]*nz+k]==0 && count3==0)
	    count3=m;
	    /*	areacount3[p[0]*ny*nz+p[1]*nz+k]=count3;*/
	    if(localdensity2[p[0]*ny*nz+p[1]*nz+k]>0){
	      count=0;
	      count2=0;
	      count3=0;
	    }
	    m++;
	  }
	  for(m=0;m<count;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount1[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  for(m=0;m<count2;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount2[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  for(m=0;m<count3;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount3[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  count=0;
	  count2=0;
	  count3=0;
	  m=0;
	  p[0]=com[0];
	  p[1]=com[1];
	}
	
	for(i=0;i<nx;i++){
	  unitr[0]=i-com[0];
	  unitr[1]=ny-com[1];
	  invlength=1/sqrt(unitr[0]*unitr[0]+unitr[1]*unitr[1]);
	  unitr[0]=unitr[0]*invlength;
	  unitr[1]=unitr[1]*invlength;
	  while(p[0]>0 && p[1]>0 && p[0]<nx && p[1]<ny){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    if(areacount[p[0]*ny*nz+p[1]*nz+k]>0 && count==0)
	      count=m;
	    /*	areacount1[p[0]*ny*nz+p[1]*nz+k]=count;*/
	    if(localdensity[p[0]*ny*nz+p[1]*nz+k]>localdensity2[p[0]*ny*nz+p[1]*nz+k] && count2==0)
	      count2=m;
	    /*	areacount2[p[0]*ny*nz+p[1]*nz+k]=count2;*/
	    if(areacount[p[0]*ny*nz+p[1]*nz+k]>0 && localdensity2[p[0]*ny*nz+p[1]*nz+k]==0 && count3==0)
	      count3=m;
	    /*	areacount3[p[0]*ny*nz+p[1]*nz+k]=count3;*/
	    if(localdensity2[p[0]*ny*nz+p[1]*nz+k]>0){
	      count=0;
	      count2=0;
	      count3=0;
	    }
	  m++;
	  }
	  for(m=0;m<count;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount1[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  for(m=0;m<count2;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount2[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  for(m=0;m<count3;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount3[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  count=0;
	  count2=0;
	  count3=0;
	  m=0;
	  p[0]=com[0];
	  p[1]=com[1];
	  
	}
	
	for(i=0;i<ny;i++){                                                                                                                  
	  unitr[0]=-com[0];                                                                                                                 
	  unitr[1]=i-com[1];                                                                                                                
	  invlength=1/sqrt(unitr[0]*unitr[0]+unitr[1]*unitr[1]);                                                                            
	  unitr[0]=unitr[0]*invlength;                                                                                                      
	  unitr[1]=unitr[1]*invlength;                                                                                                      
	  while(p[0]>0 && p[1]>0 && p[0]<nx && p[1]<ny){                                                                                    
	    p[0]=com[0]+(int)m*unitr[0];                                                                                                    
	    p[1]=com[1]+(int)m*unitr[1];                                                                                                    
	    if(areacount[p[0]*ny*nz+p[1]*nz+k]>0 && count==0)
	      count=m;
	    /*	areacount1[p[0]*ny*nz+p[1]*nz+k]=count;*/
	    if(localdensity[p[0]*ny*nz+p[1]*nz+k]>localdensity2[p[0]*ny*nz+p[1]*nz+k] && count2==0)
	      count2=m;
	    /*	areacount2[p[0]*ny*nz+p[1]*nz+k]=count2;*/
	    if(areacount[p[0]*ny*nz+p[1]*nz+k]>0 && localdensity2[p[0]*ny*nz+p[1]*nz+k]==0 && count3==0)
	      count3=m;
	    /*	areacount3[p[0]*ny*nz+p[1]*nz+k]=count3;*/
	    if(localdensity2[p[0]*ny*nz+p[1]*nz+k]>0){
	      count=0;
	      count2=0;
	      count3=0;
	    }
	    
	    m++;                                                                                                                            
	  }        
	  for(m=0;m<count;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount1[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  for(m=0;m<count2;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount2[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  for(m=0;m<count3;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount3[p[0]*ny*nz+p[1]*nz+k]=1;
	  }                                                                                                                         
	  count=0; 
	  count2=0;
	  count3=0;                                                                                                                         
	  m=0;                                                                                                                              
	  p[0]=com[0];                                                                                                                      
	  p[1]=com[1];                                                                                                                      
	  
	}                                                                                                                                   
	
	for(i=0;i<ny;i++){                                                                                                                  
	  unitr[0]=nx-com[0];                                                                                                               
	  unitr[1]=i-com[1];                                                                                                                
	  invlength=1/sqrt(unitr[0]*unitr[0]+unitr[1]*unitr[1]);                                                                            
	  unitr[0]=unitr[0]*invlength;                                                                                                      
	  unitr[1]=unitr[1]*invlength;                                                                                                      
	  while(p[0]>0 && p[1]>0 && p[0]<nx && p[1]<ny){
	    if(areacount[p[0]*ny*nz+p[1]*nz+k]>0 && count==0)
	      count=m;
	    /*	areacount1[p[0]*ny*nz+p[1]*nz+k]=count;*/
	    if(localdensity[p[0]*ny*nz+p[1]*nz+k]>localdensity2[p[0]*ny*nz+p[1]*nz+k] && count2==0)
	      count2=m;
	    /*	areacount2[p[0]*ny*nz+p[1]*nz+k]=count2;*/
	    if(areacount[p[0]*ny*nz+p[1]*nz+k]>0 && localdensity2[p[0]*ny*nz+p[1]*nz+k]==0 && count3==0)
	      count3=m;
	    /*	areacount3[p[0]*ny*nz+p[1]*nz+k]=count3;*/
	    if(localdensity2[p[0]*ny*nz+p[1]*nz+k]>0){
	      count=0;
	      count2=0;
	      count3=0;
	      /* if(p[0]>40)
		 fprintf(stderr,"%i %i %i %i %f %f \n",count,m,p[0],p[1],areacount[p[0]*ny*nz+p[1]*nz+k],localdensity2[p[0]*ny*nz+p[1]*nz+k]);*/
	    }
	    m++;                                                                                                                            
	    p[0]=com[0]+(int)m*unitr[0];                                                                                                    
	    p[1]=com[1]+(int)m*unitr[1];
	  }
	  for(m=0;m<count;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount1[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  for(m=0;m<count2;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount2[p[0]*ny*nz+p[1]*nz+k]=1;
	  }
	  for(m=0;m<count3;m++){
	    p[0]=com[0]+(int)m*unitr[0];
	    p[1]=com[1]+(int)m*unitr[1];
	    areacount3[p[0]*ny*nz+p[1]*nz+k]=1;
	  }                                                                                                                                 
	  count=0;                                                                                                                          
	  count2=0;
	  count3=0;
	  m=0;                                                                                                                              
	  p[0]=com[0];                                                                                                                      
	  p[1]=com[1];                                                                                                                      
	}                                                                                                                                   
      }
      
      for(i=0;i<nx;i++)
	for(j=0;j<ny;j++)
	  for(k=0;k<nz;k++){
	    area[k]+=areacount1[i*ny*nz+j*nz+k];
	    area2[k]+=areacount2[i*ny*nz+j*nz+k];
	    area3[k]+=areacount3[i*ny*nz+j*nz+k];
	  }
  
  
      for(i=0;i<nx;i++)
	for(j=0;j<ny;j++)   
	  for(k=0;k<nz;k++){
	    areacount[i*ny*nz+j*nz+k]=0;
	    localdensity[i*ny*nz+j*nz+k]=0;
	    localdensity2[i*ny*nz+j*nz+k]=0;
	  }
      
      /*      for(k=0;k<nz;k++)
	      fprintf(AREAout,"%f %f \n",k* *slicesize,area[k]* *slicesize * *slicesize);*/
      
      /* fprintf(AREAout,"%s \n","&");*/
      nr_frames2++;
      nr_frames=0;
    }  
    } while (read_next_x(status,&t,natoms,x0,box));
    
    for(k=0;k<nz;k++)
      fprintf(AREAout,"%f %f %f %f \n",k* *slicesize,area[k]* *slicesize * *slicesize/nr_frames2,area2[k]* *slicesize * *slicesize/nr_frames2,area3[k]* *slicesize * *slicesize/nr_frames2);
    

  for(k=0;k<nx*ny*nz;k++)
    {
      if(localdensity[k] > max)
	max = localdensity2[k];
      if(localdensity[k] < min)
	min = localdensity2[k];
    }
  
  for(i=0;i<nx;i++)
    for(j=0;j<ny;j++)   
      for(k=0;k<nz;k++)
	{
	  fprintf(putget2,"%f %f %f %f \n",i*1.0* *slicesize,j*1.0* *slicesize,k*1.0* *slicesize,localdensity[i*ny*nz+j*nz+k]);
	  /*	  if(localdensity2[i*ny*nz+j*nz+k]>0 && i>40)*/
	  fprintf(putget,"%-6s%5u  %-4.4s%3.3s %c%4d    %8.3f%8.3f%8.3f%6.2f%6.2f \n","ATOM ",(i+j+k+1)%10000,"CA","ALA",' ',(i+j+k+1)%10000,i*1.0,j*1.0,k*1.0,1.0,areacount1[i*ny*nz+j*nz+k]);
	  /*	  else
	      fprintf(putget,"%-6s%5u  %-4.4s%3.3s %c%4d    %8.3f%8.3f%8.3f%6.2f%6.2f \n","ATOM ",(i+j+k+1)%10000,"CA","ALA",' ',(i+j+k+1)%10000,i*1.0,j*1.0,k*1.0,1.0,0.0);*/
	}
  
  /*********** done with status file **********/
  /*  close_trj(status);*/
  fclose(putget);
  fclose(putget2);
  fclose(AREAout);
/* slDensity now contains the total number of electrons per slice, summed 
   over all frames. Now divide by nr_frames and volume of slice 
*/

/*  fprintf(stderr,"\nRead %d frames from trajectory. Counting electrons\n",
	  nr_frames);
	  fprintf(stderr,"In total %.1lf electrons in the last frame\n", sum1);*/

  /*  for (n =0; n < nr_grps; n++) {
    for (i = 0; i < *nslices; i++)
      (*slDensity)[n][i] = (*slDensity)[n][i] / nr_frames;
      }*/

  /* sfree(x0);*/  /* free memory used by coordinate array */

}

void plot_density(real *slDensity[], char *afile, int nslices,
		  int nr_grps, char *grpname[], real slWidth, 
		  bool bElectron, bool bNumber, bool bCount, float center)
{
  FILE       *den;     /* xvgr file with density   */
  char       buf[256]; /* for xvgr title */
  int        slice, n;
  float      shift;

  sprintf(buf,"Partial densities");
  if (bElectron)
    den = xvgropen(afile, buf, "Box (nm)", "Electron density (e/nm\\S3\\N)");
  else if (bNumber)
    den = xvgropen(afile, buf, "Box (nm)","Density (atoms/nm\\S3\\N)");
  else if (bCount)
    den = xvgropen(afile, buf, "Slice","Absolute numbers");
  else
    den = xvgropen(afile, buf, "Box (nm)","Density (kg/m\\S3\\N)");

  xvgr_legend(den,nr_grps,grpname);

/* PSN 30.7.2004 */

  if(center > 0) 
    shift = center;
  else
    shift = nslices*slWidth/2;  

  for (slice = 0; slice < nslices; slice++) { 
    fprintf(den,"%12g  ", slice * slWidth - shift + slWidth/2.0);
    for (n = 0; n < nr_grps; n++)
	fprintf(den,"   %12g", slDensity[n][slice]);
    fprintf(den,"\n");
  }
/* PSN 30.7.2004 */

  fclose(den);
}
 
int main(int argc,char *argv[])
{
  static char *desc[] = {
    "Compute partial densities across the box, using an index file. Densities",
    "in kg/m^3, number densities or electron densities can be",
    "calculated. For electron densities, a file describing the number of",
    "electrons for each type of atom should be provided using [TT]-ei[tt].",
    "It should look like:[BR]",
    "   2[BR]",
    "   atomname = nrelectrons[BR]",
    "   atomname = nrelectrons[BR]",
    "The first line contains the number of lines to read from the file.",
    "There should be one line for each unique atom name in your system.",
    "The number of electrons for each atom is modified by its atomic",
    "partial charge.[BR]",
    "[BR]",
    "Modifications by PSN: CM-motion of bilayer taken into account and",
    "atom TYPES(!) used for electron searching instead of atom names!"
  };
  
  static bool bCharge=FALSE;                  /* calculate charge density   */
  static int  axis = 2;                       /* normal to memb. default z  */
  static char *axtitle="Z"; 
  static real  slicesize = 0.3;                   /* nr of slices defined       */
  float center = -1.0;                        /* centering of the graph     */
  bool  bRC = FALSE;                          /* read centres ?            */
  t_pargs pa[] = {
    { "-center", FALSE, etREAL, {&center}, 
      "Shift of the z-coordinate, DEFAULT = center to 0.0" },
    { "-bRC", FALSE, etBOOL, {&bRC}, 
      "Read cm-coordinates vs. time from \"centres.dat\"" },
    { "-d", FALSE, etSTR, {&axtitle}, 
      "Take the normal on the membrane in direction X, Y or Z." },
    { "-sl",  FALSE, etREAL, {&slicesize},
      "Divide the box in cubes with size #nr." },
    { "-qdens",      FALSE, etBOOL, {&bCharge},
      "Calculate charge density instead of electron density" },
  };

  static char *bugs[] = {
  };
  int  ePBC;
  real     **density,                       /* density per slice          */
    slWidth;                                /* width of one slice         */
  char      **grpname;            	    /* groupnames                 */
  int       ngrps = 0,                      /* nr. of groups              */
    nr_electrons,                           /* nr. electrons              */
    *ngx;                                   /* sizes of groups            */
  t_topology *top;                	    /* topology 		  */ 
  atom_id   **index;             	    /* indices for all groups     */
  t_filenm  fnm[] = {             	    /* files for g_order 	  */
    { efTRX, "-f", NULL,  ffREAD },    	    /* trajectory file 	          */
    { efNDX, NULL, NULL,  ffOPTRD },    	    /* index file 		  */
    { efTPX, NULL, NULL,  ffREAD },    	    /* topology file           	  */
    { efDAT, "-ei", "electrons", ffOPTRD },   /* file with nr. of electrons */
    { efXVG,"-o","density",ffWRITE }, 	    /* xvgr output file 	  */
  };
  t_electron *el_tab;                       /* tabel with nr. of electrons*/
  
#define NFILE asize(fnm)

  CopyRight(stderr,argv[0]);

  parse_common_args(&argc,argv,PCA_CAN_VIEW | PCA_CAN_TIME | PCA_BE_NICE,
		    NFILE,fnm,asize(pa),pa,asize(desc),desc,asize(bugs),bugs);

  /* Calculate axis */
  axis = toupper(axtitle[0]) - 'X';
  
  top = read_top(ftp2fn(efTPX,NFILE,fnm),&ePBC);     /* read topology file */

  printf("How many groups? ");
  do { scanf("%d",&ngrps); } while (ngrps <= 0);
  
  snew(grpname,ngrps);
  snew(index,ngrps);
  snew(ngx,ngrps);

  if(!bRC && bCharge) {
      fprintf(stderr, "ERROR: Must use -bRC with -qdens !!!");
      exit(1);
  }
 
  get_index(&top->atoms,ftp2fn_null(efNDX,NFILE,fnm),ngrps,ngx,index,grpname); 

  if(!bCharge) {
    nr_electrons =  get_electrons(&el_tab,ftp2fn(efDAT,NFILE,fnm));
    fprintf(stderr,"Read %d atomtypes from datafile\n", nr_electrons);
  }

  calc_electron_density(ftp2fn(efTRX,NFILE,fnm),index, ngx, &density, 
                        &slicesize, top, ePBC, axis, ngrps, &slWidth, el_tab, 
                        nr_electrons, bRC, bCharge);

  /*  plot_density(density, opt2fn("-o",NFILE,fnm),
      nslices, ngrps, grpname, slWidth, TRUE, FALSE, FALSE, center);*/
  
  do_view(opt2fn("-o",NFILE,fnm), NULL);       /* view xvgr file */
  thanx(stderr);
  return 0;
}
